import api from '../api/products';
import endpoints from '../application/config'

export function getAllProductsAsync() {
    const request = {
      method: 'POST',
      headers: {
				Accept: 'application/json',
				['Content-Type']: 'application/json'
			},
		};

		fetch("http://private-24556-wdiaz1992.apiary-mock.com/getAllproducts",request)
		.then(
			res => res.json()
		)
		.then((data) => {
			return data;
		})
		.catch(console.log)
}

export function getSetProductAsync(data) {
		const request = {
      method: 'POST',
      headers: {
        Accept: 'application/json',
				['Content-Type']: 'application/json'
      },
      body: JSON.stringify(data)
		};

		fetch("https://private-24556-wdiaz1992.apiary-mock.com/setProduct",request)
		.then(
			res => res.json()
		).then((data) => {
			return data;
		})
		.catch(console.log)
}