export const publicPath = '/';

export const routeCodes = {
  HOMEPAGE: publicPath,
  CATALOGO: `${ publicPath }catalogo`,
  REGISTRO_PRODUCTOS: `${ publicPath }registro-productos`,
};