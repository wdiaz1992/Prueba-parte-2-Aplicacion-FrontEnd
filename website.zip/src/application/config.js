const endpoints = {
	'marketplace-allproducts': 'http://private-24556-wdiaz1992.apiary-mock.com/getAllproducts',
	'marketplace-newProduct': 'https://private-24556-wdiaz1992.apiary-mock.com/confirmation',
};