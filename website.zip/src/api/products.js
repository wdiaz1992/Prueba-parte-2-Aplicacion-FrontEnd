import 'whatwg-fetch';
import endpoints from '../application/config'

function getAllProducts() {
	const url = `${ endpoints['marketplace-allproducts'] }`;
	
	return url;
	/*return fetch(url, data)
	.then((response) => {
		return response;
	});*/
}

function setProduct() {
	const url = `${ endpoints['marketplace-newProduct'] }`;
	
	/*return fetch(url, data)
	.then((response) => {
		return response;
	});*/

	return url;
}

export default {
	getAllProducts,
	setProduct
};