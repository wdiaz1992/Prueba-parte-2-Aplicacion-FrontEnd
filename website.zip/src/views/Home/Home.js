import React, { Component } from "react";

class Home extends Component {
  render() {

    return (
      <div className="container">
        <div class="card card-primary">
          <div class="card-header">
            <h2>BIENVENIDO A MARKET PLACE</h2>
          </div>
          <div class="card-body">
            <p className="card-text">Ofrecemos productos de calidad</p>
          </div>
        </div>
      </div>
    );
  }
}
 
export default Home;