import React, { Component } from "react";
import PropTypes from 'prop-types';
import {getAllProductsAsync} from '../../actions/products'

class Catalog extends Component {
  static propTypes = {
		dispatch: PropTypes.func
  }
  
  constructor(props) {
		super(props);
		
		this.state = {
      tableProducts:null,
		};
  }

  componentDidMount(){
    let valor = getAllProductsAsync();

    this.setState({
      tableProducts: valor,
    });
  }
  
  getProducts(){
    const {tableProducts} = this.state;

    return (
      <div>
        tableProducts.items.map((item, index) => {
          item
        });
      </div>
    );
  }

  render() {
    return (
      <div class="container">
        <h2>Mira nuestro nuevo catalogo</h2>
        {this.getProducts()}
      </div>
    );
  }
}
 
export default Catalog;