import React from 'react'
import { Route, Switch } from 'react-router-dom'
import { routeCodes } from './application/routesConfig';
import Menu from "./components/Menu/Menu"

// We will create these two pages in a moment
import Home from './views/Home/Home'
import Catalog from './views/Catalog/index'
import ResgistroProducto from './views/Product/index'

export default function App() {
  return (
		<div className={"container-fluid"}>
			<Menu/>
			<Switch>
				<Route exact path={routeCodes.HOMEPAGE} component={Home} />
				<Route path={routeCodes.CATALOGO} component={Catalog} />
				<Route path={ routeCodes.REGISTRO_PRODUCTOS} component={ ResgistroProducto } />
			</Switch>
		</div>
  )
}